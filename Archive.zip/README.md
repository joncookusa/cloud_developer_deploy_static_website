# Sample of how to deploy a static website using AWS
This is a simple example of how to deploy a static website to the cloud. The project shows a number of screen shots to show the creation of an S3 bucket and the upload of the website to the same S3 bucket, along with the securing of the website using IAM policies, and the creation of a cloudfront distribution to deliver the website.

The URL for the travel blog is…

http://d2im6mvw2zeiuu.cloudfront.net/index.html
